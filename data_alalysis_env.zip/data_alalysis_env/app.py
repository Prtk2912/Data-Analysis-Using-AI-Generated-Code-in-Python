import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load data
@st.cache_data  # This decorator helps cache the data
def load_data():
    df = pd.read_csv('train.csv')
    return df

df = load_data()

# Add title and description
st.title('Titanic Dataset Analysis')
st.write('This app analyzes the Titanic dataset.')

# Display raw data
if st.checkbox('Show raw data'):
    st.write(df)

# Create visualizations
st.subheader('Survival Count')
fig, ax = plt.subplots()
sns.countplot(x='Survived', data=df, ax=ax)
st.pyplot(fig)

# Add more visualizations and analyses from your notebook
# ...

# Interactive elements
selected_class = st.selectbox('Select Passenger Class', [1, 2, 3])
class_data = df[df['Pclass'] == selected_class]
st.write(f'Survival rate for class {selected_class}:', 
         class_data['Survived'].mean())